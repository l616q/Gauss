"""
Definition of operation types.

These are currently examples for overriding codegen.

Feel free to propose better package name or hierarchy.
"""

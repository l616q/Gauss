# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

from .apply_compression import apply_compression_results

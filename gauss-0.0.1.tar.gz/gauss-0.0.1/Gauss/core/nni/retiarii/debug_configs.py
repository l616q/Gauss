# we will support tensorflow in future release

framework = 'pytorch'
